package com.luckygr8.mafia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Screen_2 extends AppCompatActivity {

    private RelativeLayout relativeLayout;
    private TextView screen_2_textview;

    private int number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_2);

        Init();

        number = getIntent().getIntExtra("number" ,0);
        setColor(Constants.getColor());
        screen_2_textview.setText(" please hand over the device \n to player "+number+" ");
    }

    public void setColor(String color){
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor(color));
        relativeLayout.setBackgroundColor(Color.parseColor(color));
    }

    public void Init(){
        relativeLayout = findViewById(R.id.screen_2_relativelayout);
        screen_2_textview = findViewById(R.id.screen_2_textview);
    }

    public void screen_3(View view) {
        Intent intent = new Intent(Screen_2.this,Screen_3.class);
        intent.putExtra("number",number);
        startActivity(intent);
        finish();
    }



    private boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}
