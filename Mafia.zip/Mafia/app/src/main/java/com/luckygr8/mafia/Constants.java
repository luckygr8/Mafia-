package com.luckygr8.mafia;

import android.graphics.Color;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

public class Constants {
    private static String[] colors = {"#21d1de","#2453e0","#d61893","#d49817","#cf5117","#1187ab","#10ad90","#a1a87e","#8dc5c9","#f551a0"};
    private static List<String> actions = new LinkedList<>();

    private static int CURRENT_TURN=1;
    public static Player getCURRENT_TURNplayer() {
        return PLAYERS_LIST.get(CURRENT_TURN-1);
    }

    public static int getCurrentTurn() {
        return CURRENT_TURN;
    }

    public static void clearturn(){
        CURRENT_TURN=1;
    }

    public static void setCURRENT_TURN(int current_turn) {
        if(current_turn==getNumberOfPlayers()+1)
            clearturn();
        else
        CURRENT_TURN = current_turn;
    }

    public static String getColor(){
        int random = (int)(Math.random()*colors.length);;

        return colors[random];
    }

    private static List<Player> PLAYERS_LIST = new LinkedList<>();
    private static int NUMBER_OF_PLAYERS;
    private static List<String> GeneratedCodes = new LinkedList<>();

    public static void setNumberOfplayers(int num){
        NUMBER_OF_PLAYERS = num;
        actions.add("mafia");
        actions.add("detective");
        actions.add("healer");
        for(int i=0;i<num-3;i++)
                actions.add("common");
    }

    public static boolean NameIstaken(String name){
        for(Player player : PLAYERS_LIST)
            if(player.getName().equals(name))
                return true;
            return false;
    }

    public static String getRole(){
        if(actions.size()<0)
            return null;
        while (true){
            int rand = (int)(Math.random()*actions.size());
            if(actions.get(rand)!=null){
                String role = actions.get(rand);
                actions.set(rand,null);
                return role;
            }
        }
    }

    @Deprecated
    public static String GetDetailsOfAllPlayers(){
        String details="";

        for(Player player : PLAYERS_LIST)
            details+=player.toString()+"\n";
        return details;
    }

    public static int getNumberOfPlayers(){
        return NUMBER_OF_PLAYERS;
    }


    public static void AddPlayerCodeandRole(String name,String code,String role){

        PLAYERS_LIST.add(new Player(name, code, role));
    }

    public static Player getPlayer(String name,String code){
        for(Player player : PLAYERS_LIST)
            if(player.getName().equals(name)&&player.getCode().equals(code))
                return player;

            return null;
    }

    public static void KillPlayer(String name , String role){
        for(int i=0;i<PLAYERS_LIST.size();i++)
        {
            Player p = PLAYERS_LIST.get(i);
            if(p.getName().equals(name)&&p.getRole().equals(role))
                PLAYERS_LIST.remove(i);
        }
    }

    public static List<Player> getPlayersList() {
        return PLAYERS_LIST;
    }

    public static int PlayerListSize(){
        return PLAYERS_LIST.size();
    }
    private static int size=2;
    public static String getRandomCode()
    {
        while(true){
            String AlphaNumericString ="0123456789";

            StringBuilder sb = new StringBuilder(size);

            for (int i = 0; i < size; i++) {

                int index
                        = (int)(AlphaNumericString.length()
                        * Math.random());

                sb.append(AlphaNumericString
                        .charAt(index));
            }
            if(!GeneratedCodes.contains(sb.toString())){
                GeneratedCodes.add(sb.toString());
                return  sb.toString();
            }
        }

    }

    public static String getActionAccordingToRole(String role){
        switch (role){
            case "mafia":return "kill";
            case "detective":return "arrest";
            case "healer": return "save";
            default: return "pray for mercy";
        }
    }


}
