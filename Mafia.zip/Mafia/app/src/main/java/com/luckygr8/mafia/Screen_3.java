package com.luckygr8.mafia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

public class Screen_3 extends AppCompatActivity {

    private RelativeLayout relativeLayout;
    private TextInputEditText screen_3_textinputedittext;
    private TextView screen_3_textview;
    private int number;
    private MaterialButton screen_3_next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_3);

        Init();

        setColor(Constants.getColor());
    }

    public void Init(){

        number = getIntent().getIntExtra("number",0);

        screen_3_next = findViewById(R.id.screen_3_next);
        relativeLayout = findViewById(R.id.screen_3_relativelayout);
        screen_3_textinputedittext = findViewById(R.id.screen_3_textinputedittext);
        screen_3_textview = findViewById(R.id.screen_3_textview);

        screen_3_next.setEnabled(false);
    }

    public void setColor(String color){
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor(color));
        relativeLayout.setBackgroundColor(Color.parseColor(color));
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void Continue(View view) {
        String name = screen_3_textinputedittext.getText().toString();
        if(name.isEmpty() || Constants.NameIstaken(name)){
            Snackbar.make(relativeLayout,"please enter a name",Snackbar.LENGTH_LONG).
                    setAction("okay", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    })
                    .show();
        }else{
            hideKeyboard(Screen_3.this);
            String code = Constants.getRandomCode();
            String role = Constants.getRole();

            Constants.AddPlayerCodeandRole(name,code,role);

            screen_3_textview.setText(" You are "+role+" \n secret code : "+code+"  ");
            screen_3_next.setEnabled(true);
        }
    }

    public void OpenScreen2(int number){
        Intent intent = new Intent(Screen_3.this,Screen_2.class);
        intent.putExtra("number",number);
        startActivity(intent);
        finish();
    }

    public void OpenScreen4(){
        Intent intent = new Intent(Screen_3.this,Screen_4.class);
        String name = Constants.getCURRENT_TURNplayer().getName();
        Constants.setCURRENT_TURN(1);
        intent.putExtra("name",name);
        intent.putExtra("turn",Constants.getCurrentTurn());
        startActivity(intent);
        finish();
    }

    public void screen_2or4(View view) {
        if(number<Constants.getNumberOfPlayers())
            OpenScreen2(++number);
        else
            OpenScreen4();

    }

    private boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}
