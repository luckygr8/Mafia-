package com.luckygr8.mafia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.material.snackbar.Snackbar;

public class OpeningScreen extends AppCompatActivity {

    private SeekBar seekBar;
    private TextView players;
    private LottieAnimationView play;
    private View OpeningView;

    private int total=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opening_screen);

        Init();

        EnableSlider();

        EnablePlay();
    }

    public void Init(){
        seekBar = findViewById(R.id.seekBar);
        players = findViewById(R.id.players);
        play = findViewById(R.id.play);
        OpeningView = findViewById(R.id.openingview);
    }

    public void EnablePlay(){
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(total<3)
                {
                    Snackbar.make(OpeningView,"please select more members",Snackbar.LENGTH_LONG)
                            .setAction("okay", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                }
                            })
                            .show();
                }
                else{
                    Intent intent = new Intent(OpeningScreen.this,Screen_2.class);
                    Constants.setNumberOfplayers(total);
                    intent.putExtra("number",1);
                    startActivity(intent);
                    finish();

                    /*Intent intent = new Intent(OpeningScreen.this,Screen_4.class);
                    Constants.setNumberOfplayers(total);
                    intent.putExtra("number",1);
                    startActivity(intent);
                    finish();*/
                }
            }
        });
    }

    public void EnableSlider(){
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                total = seekBar.getProgress();
                if(total<3)
                    players.setText(" select more members ");
                else
                    players.setText(" " +total+" players ");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
}
