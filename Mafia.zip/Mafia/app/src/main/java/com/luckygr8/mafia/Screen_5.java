package com.luckygr8.mafia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ScrollView;

public class Screen_5 extends AppCompatActivity {

    private ScrollView screen_5_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_5);
        Init();

        setColor(Constants.getColor());
    }

    public void setColor(String color){
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor(color));
        screen_5_layout.setBackgroundColor(Color.parseColor(color));
        screen_5_layout.setBackgroundColor(Color.parseColor(color));
    }

    public void Init(){
        screen_5_layout = findViewById(R.id.screen_5_layout);
    }

    public void nextRound(View view) {
        Intent intent = new Intent(this,Screen_4.class);
        Constants.setCURRENT_TURN(1);
        String name = Constants.getCURRENT_TURNplayer().getName();
        intent.putExtra("name",name);
        intent.putExtra("turn",Constants.getCurrentTurn());
        startActivity(intent);
        finish();

    }
}
