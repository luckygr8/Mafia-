package com.luckygr8.mafia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Screen_4 extends AppCompatActivity {

    private LinearLayout screen_4_layout1,screen_4_layout2;
    private TextView screen_4_textview1,screen_4_l2_youare,screen_4_l2_action;
    private Spinner screen_4_recyclerview;
    private TextInputEditText screen_4_textinputedittext;
    private int turn;
    private List<Player> playerList;
    private List<String> names = new LinkedList<>();
    private String name;

    private Player tobedeleted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen_4);
        Init();

        name = getIntent().getStringExtra("name");
        turn = getIntent().getIntExtra("turn",0);

        DisplayName(name);

        setColor(Constants.getColor());
    }

    /**public void SetGameLoop(){
        while(true){
            for(int i=0;i<Constants.getNumberOfPlayers();i++){
                DisplayName(name);
            }
        }
    }*/

    public void DisplayName(String name){
        System.out.println(Constants.getCURRENT_TURNplayer().toString());
        System.out.println(turn);
        screen_4_textview1.setText(" Player "+name+"'s turn ");
    }

    public void setColor(String color){
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.parseColor(color));
        screen_4_layout1.setBackgroundColor(Color.parseColor(color));
        screen_4_layout2.setBackgroundColor(Color.parseColor(color));
    }

    public void Init(){
        screen_4_layout1 = findViewById(R.id.screen_4_layout1);
        screen_4_textview1 = findViewById(R.id.screen_4_textview1);
        screen_4_layout2 = findViewById(R.id.screen_4_layout2);
        screen_4_l2_youare = findViewById(R.id.screen_4_l2_youare);
        screen_4_l2_action = findViewById(R.id.screen_4_l2_action);
        screen_4_recyclerview = findViewById(R.id.screen_4_recyclerview);
        screen_4_textinputedittext = findViewById(R.id.screen_4_textinputedittext);


    }

    public void reveal(View view) {
        String code = screen_4_textinputedittext.getText().toString();


        Player player = Constants.getPlayer(name,code);
        if(player.getRole().equals("common"))
            tobedeleted = player;
        if(player!=null){
            names.clear();
            if(player.getRole().equals("detective"))
                names.add("Maybe I will arrest next time");
            screen_4_layout1.setVisibility(View.GONE);
            screen_4_layout2.setVisibility(View.VISIBLE);
            String role = player.getRole();
            screen_4_l2_youare.setText(" You are : "+role+" ");
            String action = Constants.getActionAccordingToRole(role);
            screen_4_l2_action.setText(" Your task : "+action+" ");

            if(!player.getRole().equals("common")){
                screen_4_recyclerview.setVisibility(View.VISIBLE);
                playerList = Constants.getPlayersList();
                Iterator<Player> iterator = playerList.iterator();
                while(iterator.hasNext()){
                    Player p = iterator.next();
                    if(!p.getName().equals(name)||p.getRole().equals("healer"))
                        names.add(p.getName());
                }

                ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
                arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                screen_4_recyclerview.setAdapter(arrayAdapter);
            }
            else{
                screen_4_recyclerview.setVisibility(View.INVISIBLE);
            }

            screen_4_textinputedittext.setText("");

        }else{

            Snackbar.make(screen_4_layout1,"please enter correct code",Snackbar.LENGTH_LONG).
                    setAction("okay", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    })
                    .show();

        }

    }
    public void openScreen_5(){
        Constants.clearturn();
        Constants.KillPlayer(tobedeleted.getName(),tobedeleted.getRole());
        Intent intent = new Intent(Screen_4.this,Screen_5.class);
        startActivity(intent);
        finish();
    }

    public void proceed(View view) {

        Constants.setCURRENT_TURN(++turn);
        name = Constants.getCURRENT_TURNplayer().getName();
        DisplayName(name);
        screen_4_layout1.setVisibility(View.VISIBLE);
        screen_4_layout2.setVisibility(View.GONE);
        setColor(Constants.getColor());

        if(turn==Constants.getNumberOfPlayers()+1)
            openScreen_5();

    }
}
