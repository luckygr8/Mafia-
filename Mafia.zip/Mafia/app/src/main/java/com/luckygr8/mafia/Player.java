package com.luckygr8.mafia;

public class Player {
    private String name,code,role;
    private boolean isIn;

    public void setIn(boolean in) {
        isIn = in;
    }

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", code='" + code + '\'' +
                ", role='" + role + '\'' +
                '}';
    }

    public Player(String name, String code, String role) {
        this.name = name;
        this.code = code;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public String getRole() {
        return role;
    }
}
